const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middlewares
app.use(cors());
app.use(bodyParser.json());

// Rota de validação de login
app.post('/api/login', (req, res) => {
  const { email, senha } = req.body;

  if (email === 'user@email.com' && senha === 'senha') {
    res.status(200).json({ sucesso: true, mensagem: 'Login bem-sucedido' });
  } else {
    res.status(401).json({ sucesso: false, mensagem: 'Credenciais inválidas' });
  }
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`Servidor iniciado em http://192.168.0.2:${port}`);
});
