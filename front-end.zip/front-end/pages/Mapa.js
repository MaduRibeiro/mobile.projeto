import React from "react";
import Maps from "../components/Maps.js";
import Perfil from "../components/Perfil"

const Mapa = () => {

  return (
    <>
      <Maps />
      <Perfil />
    </>
  );
}

export default Mapa;