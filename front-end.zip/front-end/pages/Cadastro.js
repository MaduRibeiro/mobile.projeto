import FormCadastro from "../components/FormCadastro";

function Cadastro(){
    return(
        <>
        <FormCadastro />
        </>
    )
}

export default Cadastro;