import React, { useEffect, useState } from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import Icon from 'react-native-vector-icons/FontAwesome5';
import haversine from 'haversine';
import vistCivil from './VistoriaCivil';

const Maps = () => {
  const [location, setLocation] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [vistorias, setVistorias] = useState([]);
  const [ponto, setPonto] = useState(null);
  const [modal, setModal] = useState(false);
  const [distance, setDistance] = useState(null);

  useEffect(() => {
    requestLocation();
    setVistorias(vistCivil.features);
  }, []);

  const requestLocation = async () => {
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMessage('Permission to access location was denied');
        return;
      }

      let userLocation = await Location.getCurrentPositionAsync({});
      setLocation(userLocation.coords);
    } catch (error) {
      console.error('Error getting current location:', error);
      setErrorMessage('Error getting current location');
    }
  };

  const handleMarkerPress = (point) => {
    setPonto(point);
    calculateDistance(point);
    setModal(true);
  };

  const calculateDistance = (point) => {
    if (location && point) {
      const userCoordinates = {
        latitude: location.latitude,
        longitude: location.longitude,
      };

      const pointCoordinates = {
        latitude: point.geometry.coordinates[1],
        longitude: point.geometry.coordinates[0],
      };

      const calculatedDistance = haversine(userCoordinates, pointCoordinates, { unit: 'Km' });
      setDistance(calculatedDistance);
    }
  };

  const renderModalContent = () => {
    const nivel = ponto && ponto.properties ? ponto.properties.Nível : null;

    let corNivelTexto;
    if (nivel === 0) {
      corNivelTexto = "#00FF00";
    } else if (nivel === 1 || nivel === 2) {
      corNivelTexto = "#FFD700";
    } else {
      corNivelTexto = "#FF0000";
    }

    return (
      <View style={styles.modalContent}>
        <Text style={[styles.textRisco, { color: corNivelTexto }]}>
          {ponto && ponto.properties.Descrição}
        </Text>
        <Text style={styles.text}>{ponto && ponto.properties.Endereço}</Text>
        {distance && <Text style={styles.text}>Distância: {distance.toFixed(2)} Km</Text>}
        <TouchableOpacity
          style={styles.botao}
          onPress={() => setModal(false)}
        >
          <Text style={styles.botaoTexto}>Sair</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={{ flex: 1 }}
        region={{
          latitude: location ? location.latitude : 0,
          longitude: location ? location.longitude : 0,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        {location && (
          <Marker
            coordinate={{
              latitude: location.latitude,
              longitude: location.longitude,
            }}
          >
            <Icon name="female" size={45} color="#FFD700"/>
          </Marker>
        )}
        {vistorias.map((vistoria, index) => (
          <Marker
            key={index}
            coordinate={{
              longitude: vistoria.geometry.coordinates[0],
              latitude: vistoria.geometry.coordinates[1],
            }}
            onPress={() => handleMarkerPress(vistoria)}
          />
        ))}
      </MapView>
      <Modal
        animationType="slide"
        transparent={false}
        visible={modal}
        onRequestClose={() => {
          setModal(false);
        }}>
        {renderModalContent()}
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  modalContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  textRisco: {
    fontSize: 22,
    marginBottom: 15,
  },
  text: {
    fontSize: 18,
    color: "black",
    marginBottom: 10,
  },
  botao: {
    backgroundColor: "#50C878",
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
  },
  botaoTexto: {
    color: 'black',
    fontSize: 16,
    textAlign: 'center',
    padding: 5,
  },
});

export default Maps;